int strcmp(char*, char*);
char* strcpy(char*,const char*);